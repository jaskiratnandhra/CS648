import React from 'react';
import Products from './Products'

function App() {
  return (
    <div>
      <Products></Products>
    </div>
  );
}

export default App;